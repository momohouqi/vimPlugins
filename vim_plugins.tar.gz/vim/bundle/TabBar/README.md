Tabbar
======
This is a mirror of http://www.vim.org/scripts/script.php?script_id=1338 with many bugs fixed

Bugfixs
-------
* Do not activate in vimdiff/Macvim/Gvim
* Add Tab delete function using `:Tbbd`
* Switch tabs in any window
